# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from snippets.serializers import SnippetSerializer
from .models import DetailsModel,NotificationsModel
from django.urls import reverse_lazy
from django.views.generic import TemplateView,View,CreateView,ListView
from django.conf import settings



# Create your views here.

@csrf_exempt
def snippet_list(request):
    """
    List all code snippets, or create a new snippet.
    """
    if request.method == 'GET':
        snippets = DetailsModel.objects.all()
        serializer = SnippetSerializer(snippets, many=True)
        return JsonResponse(serializer.data, safe=False)

    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = SnippetSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)


@csrf_exempt
def snippet_detail(request, pk):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        snippet = DetailsModel.objects.get(pk=pk)
    except Snippet.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = SnippetSerializer(snippet)
        return JsonResponse(serializer.data)

    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = SnippetSerializer(snippet, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        snippet.delete()
        return HttpResponse(status=204)






class Index(TemplateView):
	template_name = 'index.html'


# class EnterDetailsView(CreateView):
# 	model = DetailsModel
# 	fields = ['person_name','person_age']
# 	template_name = 'enterdetails.html'
# 	success_url = reverse_lazy('index')
	

class ListDetailsView(ListView):
	model = DetailsModel
	template_name = 'listdetails.html'


	


def update_model_detail_view(request):
	data = {

	"count":1000,

	"content" : "some new content"

	}
	return JsonResponse( data)

class Index(View):
    template_name = 'index.html'
    def get(self,request):

        
        obj1 = NotificationsModel.objects.all()
    
        context = {
        'obj1' : obj1
        }

        return render(request,self.template_name,context)




class EnterDetailsView(View):
    model = DetailsModel
    fields = ['person_name','person_age']
    template_name = 'enterdetails1.html'
    def get (self,request):
        obj1 = DetailsModel.objects.all()
        context = {
        'obj1' : obj1
        }
        return render(request,self.template_name,context)
    def post(self,request):
        pname = request.POST.get('personName')
        print(pname)
        page = request.POST.get('personAge')
        print(page)
        obj1 =DetailsModel(person_name = str(pname) , person_age = int(page))
        obj1.save()
        NotificationsModel.objects.all().delete()
        obj1 =NotificationsModel(person_name = str(pname) , person_age = int(page))
        obj1.save()
        

        return redirect('/')