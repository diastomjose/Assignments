
from snippets import views
from django .conf.urls import url

from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [

url(r'^$',views.Index.as_view(),name = 'index'),

url(r'^testing/',views.Index.as_view(),name = 'testing'),
url(r'^snippets/', views.snippet_list,name ="snippets"),
url(r'^snippets/<int:pk>/', views.snippet_detail),
url(r'^enterdetails/',views.EnterDetailsView.as_view(),name = 'enterdetails'),
url(r'^listdetails/',views.ListDetailsView.as_view(),name = 'listdetails'),
]