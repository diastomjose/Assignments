from rest_framework import serializers
from snippets.models import DetailsModel


class SnippetSerializer(serializers.ModelSerializer):
    class Meta:
        model = DetailsModel
        fields = ('person_name', 'person_age')