app.controller("myCtrl", function($scope){
	$scope.firstName = "DIAS TOM";
	$scope.lastName = "JOSE ";

});